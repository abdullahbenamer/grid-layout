<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>CSS-Grid</title>
</head>

<body>
    <div class="parent">
        <div class="item">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>
    </div>

    <div class="parent_2">
        <div class="item_2">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente provident rem ab quod quo ullam est! Temporibus ullam reiciendis aliquid fugiat, iure debitis, fugit ad consequatur, dolorum voluptatem corrupti ipsa blanditiis perspiciatis tempore recusandae repudiandae quibusdam deserunt quos asperiores ab aut! Placeat, sit rem sequi asperiores, dolores sed minima minus.</p>
        </div>

        <div class="item_2">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item_2">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item_2">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

        <div class="item_2">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
        </div>

    </div>

    <div class="example-banner">
        <h1 class="center-me">Hello</h1>
    </div>

    <div class="full-width-example">
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et molestias nesciunt ullam nobis optio suscipit? Ullam qui facilis omnis rerum dolor eligendi reiciendis. Error, pariatur! Doloremque maiores quae blanditiis nam?</p>
    </div>

    <div class="photo-example">
        <img src="natural.jpg" alt="A nice natural view !">
        <div class="over-lay_text">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam optio consectetur magnam adipisci fugit ducimus, quasi quo quaerat, eius numquam qui modi nobis accusantium sunt voluptatibus earum reiciendis fuga iste?</p>
        </div>
    </div>

    <div class="layout">
        <div class="header">This is the Header</div>
        <div class="main">

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>


            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
        </div>

        <div class="sidebar">
            <p>The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
        </div>
        <div class="footer">&copy; - 2023</div>
    </div>


    <!-- ===== Responsive Layout example ====== -->

    <h3 style="margin-top: 30px;">Responsive Layout example</h3>

    <div class="layout2">
        <div class="header2">This is the Header</div>
        <div class="main2">

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>


            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
        </div>

        <div class="sidebar2">
            <p>The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui.</p>
            <p>Odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui.</p>
            <p>Odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui.</p>
            <p>Odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam.</p>
            <p>Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui.</p>
            <p>Odio maiores quae amet numquam perspiciatis ullam.</p>
        </div>
        <div class="footer2">&copy; - 2023</div>
    </div>


    <!-- ======================== -->

    <div class="responsive-example">
        <div class="responsive-item">Odio maiores quae amet numquam perspiciatis ullam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">Odio maiores quae amet numquam perspiciatis ullam. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">The sidebar - Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">Ratione rerum dolore qui, odio maiores quae amet numquam perspiciatis ullam. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">Qui, deleniti nulla quos officia odio distinctio a rem iusto labore. Ratione rerum dolore qui. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
        <div class="responsive-item">Odio maiores quae amet numquam perspiciatis ullam. orem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsum blanditiis quibusdam facilis repellendus omnis iure esse. Tenetur eius recusandae sint sed distinctio, voluptatibus cumque quos quaerat voluptatum non? Ipsa.</div>
    </div>


     <!-- ========== Innovation Art =================== -->


     <div class="art-banner">
        <div class="art-banner-bg"></div>
        <div class="banner-text">Lorem ipsum dolor.</div>
        <div class="badge">
        <p>New!</p>    
        </div>

</body>

</html>