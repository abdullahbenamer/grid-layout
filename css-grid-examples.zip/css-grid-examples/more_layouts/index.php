<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Document</title>
</head>
<body>
<article class="c-card">
    <div class="c-card__thumb"></div>
    <div class="c-card__content">
        <h3 class="c-card__title"></h3>
        <p class="c-card__tease"></p>
        <p class="c-card__meta"></p>
    </div>
</article>

<div class="c-newspaper">
    <div class="c-newspaper__col">
        <div class="c-newspaper__item">
            <article class="c-card">
               Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem facilis dolore optio ex veritatis impedit minima id deserunt aut. Delectus dolorem a ipsa odio ex! Enim magnam fuga unde deserunt.
            </article>
        </div>
        <div class="c-newspaper__item">Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur laboriosam iusto, dignissimos aliquid rerum ad hic velit alias assumenda ab illum consectetur, placeat tempore, voluptatibus iure facilis molestias esse architecto!</div>
        <div class="c-newspaper__item">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos voluptates sapiente eaque libero cum facilis architecto tempora accusamus necessitatibus beatae, nihil aut nam culpa dolor? Enim accusantium repellendus ex magnam?</div>
    </div>
    <!-- Other columns -->
</div>



<br>
<div class="c-entry-box--compact c-entry-box--compact--article c-entry-box--compact--hero c-entry-box--compact--2">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident quaerat facere architecto rerum quas possimus illo eveniet neque aut est voluptatem nihil dolore error quidem repellat accusamus aperiam, hic obcaecati.</div>




<div class="c-newspaper">
    <!-- Featured column -->
    <div class="c-newspaper__col">Consectetur ex reprehenderit nulla voluptate korem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis hic fuga voluptas commodi beatae amet porro eaque impedit totam at, quidem suscipit facilis. Molestias, optio quasi? Totam nam sit rem!</div>
    
    <!-- Other columns -->
    <div class="c-newspaper__col">corporis orem excepturi a ex corporis quidem ipsum dolor sit amet consectetur adipisicing elit. Eligendi pariatur dolor quisquam, eum libero magnam consequuntur iure nam corrupti, explicabo aut unde? Repudiandae aliquid nihil.</div>
    <div class="c-newspaper__col">Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat placeat rerum eos neque, maxime doloremque dolor ipsum at culpa facilis hic enim,  reiciendis, impedit minus.</div>
</div>


</body>
</html>